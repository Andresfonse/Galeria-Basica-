package com.example.galeriavbasica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
